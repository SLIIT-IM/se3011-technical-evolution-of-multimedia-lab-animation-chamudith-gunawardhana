int state = 0;
int score = 0;
int startTime;
int duration = 30;
boolean trails = false;

float playerX, playerY;
float playerRadius = 20;
float moveSpeed = 6;
float followX, followY;
float easing = 0.10;

float boxX = 300; 
float boxY = 100;
float boxW = 100;
float boxH = 150;

float orbX, orbY, orbVX, orbVY;
float orbRadius = 15;

float orb2X, orb2Y, orb2VX, orb2VY;

float goldX, goldY, goldVX, goldVY;
float goldRadius = 12;
boolean goldActive = false;

void setup() {
  size(700, 350);
  resetGame();
}

void resetGame() {
  playerX = 100;
  playerY = height/2;
  followX = playerX;
  followY = playerY;
  
  orbX = random(orbRadius, width - orbRadius);
  orbY = random(orbRadius, height - orbRadius);
  orbVX = 4;
  orbVY = 3;
  
  orb2X = random(orbRadius, width - orbRadius);
  orb2Y = random(orbRadius, height - orbRadius);
  orb2VX = -3;
  orb2VY = 5;
  
  score = 0;
  goldActive = false;
}

void draw() {
  if (state == 0) {
    showStart();
  } else if (state == 1) {
    runGame();
  } else if (state == 2) {
    showEnd();
  }
}

void showStart() {
  background(40, 50, 70);
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(32);
  text("Ball CATCHER ULTIMATE", width/2, height/2 - 40);
  textSize(18);
  text("ARROWS to move | T for Trails\nENTER to Start", width/2, height/2 + 40);
}

void runGame() {
  if (!trails) {
    background(245);
  } else {
    noStroke();
    fill(245, 40); 
    rect(0, 0, width, height);
  }

  int elapsed = (millis() - startTime) / 1000;
  int timeLeft = duration - elapsed;
  if (timeLeft <= 0) state = 2;

  float prevX = playerX;
  float prevY = playerY;

  if (keyPressed) {
    if (keyCode == RIGHT) playerX += moveSpeed;
    if (keyCode == LEFT)  playerX -= moveSpeed;
    if (keyCode == DOWN)  playerY += moveSpeed;
    if (keyCode == UP)    playerY -= moveSpeed;
  }
  
  playerX = constrain(playerX, playerRadius, width - playerRadius);
  playerY = constrain(playerY, playerRadius, height - playerRadius);

  if (playerX + playerRadius > boxX && playerX - playerRadius < boxX + boxW &&
      playerY + playerRadius > boxY && playerY - playerRadius < boxY + boxH) {
      playerX = prevX;
      playerY = prevY;
  }

  followX += (playerX - followX) * easing;
  followY += (playerY - followY) * easing;

  orbX += orbVX; orbY += orbVY;
  orb2X += orb2VX; orb2Y += orb2VY;
  
  if (orbX > width - orbRadius || orbX < orbRadius) orbVX *= -1;
  if (orbY > height - orbRadius || orbY < orbRadius) orbVY *= -1;
  if (orb2X > width - orbRadius || orb2X < orbRadius) orb2VX *= -1;
  if (orb2Y > height - orbRadius || orb2Y < orbRadius) orb2VY *= -1;

  if (dist(playerX, playerY, orbX, orbY) < playerRadius + orbRadius) {
    handleCatch(1);
  }
  if (dist(playerX, playerY, orb2X, orb2Y) < playerRadius + orbRadius) {
    handleCatch(2);
  }
  
  if (goldActive) {
    goldX += goldVX; goldY += goldVY;
    if (goldX > width - goldRadius || goldX < goldRadius) goldVX *= -1;
    if (goldY > height - goldRadius || goldY < goldRadius) goldVY *= -1;
    
    fill(255, 215, 0);
    ellipse(goldX, goldY, goldRadius * 2, goldRadius * 2);
    
    if (dist(playerX, playerY, goldX, goldY) < playerRadius + goldRadius) {
      score += 3;
      goldActive = false;
    }
  }

  fill(100);
  rect(boxX, boxY, boxW, boxH);

  fill(80, 200, 120, 150);
  ellipse(followX, followY, 16, 16);
  
  fill(60, 120, 200);
  ellipse(playerX, playerY, playerRadius * 2, playerRadius * 2);
  
  fill(255, 120, 80);
  ellipse(orbX, orbY, orbRadius * 2, orbRadius * 2);
  ellipse(orb2X, orb2Y, orbRadius * 2, orbRadius * 2);

  fill(0);
  textAlign(LEFT, TOP);
  textSize(18);
  text("Score: " + score, 20, 20);
  text("Time: " + timeLeft, 20, 45);
}

void showEnd() {
  background(20);
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(32);
  text("GAME OVER", width/2, height/2 - 40);
  fill(255, 200, 0);
  text("Final Score: " + score, width/2, height/2);
  textSize(16);
  fill(150);
  text("Press R to Restart", width/2, height/2 + 50);
}

void handleCatch(int type) {
  score++;
  if (type == 1) {
    orbX = random(orbRadius, width - orbRadius);
    orbY = random(orbRadius, height - orbRadius);
    orbVX *= 1.05; orbVY *= 1.05;
  } else {
    orb2X = random(orbRadius, width - orbRadius);
    orb2Y = random(orbRadius, height - orbRadius);
    orb2VX *= 1.05; orb2VY *= 1.05;
  }
  
  if (score % 5 == 0 && score != 0) {
    triggerGold();
  }
}

void triggerGold() {
  goldActive = true;
  goldX = random(goldRadius, width - goldRadius);
  goldY = random(goldRadius, height - goldRadius);
  goldVX = random(-6, 6);
  goldVY = random(-6, 6);
}

void keyPressed() {
  if (state == 0 && keyCode == ENTER) {
    state = 1;
    startTime = millis();
  }
  
  if (state == 2 && (key == 'r' || key == 'R')) {
    resetGame();
    state = 0;
  }
  
  if (key == 't' || key == 'T') {
    trails = !trails;
  }
}
